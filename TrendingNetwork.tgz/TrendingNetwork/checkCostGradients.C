#define nLAYER 7
#define nW 17
#define MONITOR_RANGE 300
int* NTracks;

double*** gradNetworkCost;

static constexpr int NSubStave2[nLAYER] = { 1, 1, 1, 2, 2, 2, 2 };
const int NSubStave[nLAYER] = { 1, 1, 1, 2, 2, 2, 2 };
const int NStaves[nLAYER] = { 12, 16, 20, 24, 30, 42, 48 };
const int nHicPerStave[nLAYER] = { 1, 1, 1, 8, 8, 14, 14 };
const int nChipsPerHic[nLAYER] = { 9, 9, 9, 14, 14, 14, 14 };
const int ChipBoundary[nLAYER + 1] = { 0, 108, 252, 432, 3120, 6480, 14712, 24120 };
const int StaveBoundary[nLAYER + 1] = { 0, 12, 28, 48, 72, 102, 144, 192 };

int nSensorsbyLayer[nLAYER] 		= {	ChipBoundary[1] - ChipBoundary[0],
						ChipBoundary[2] - ChipBoundary[1],
						ChipBoundary[3] - ChipBoundary[2],
						ChipBoundary[4] - ChipBoundary[3],
						ChipBoundary[5] - ChipBoundary[4],
						ChipBoundary[6] - ChipBoundary[5],
						ChipBoundary[7] - ChipBoundary[6]	};


Bool_t LoadCostGradients(Option_t * filename, double** gradCost)
{
   TString filen = filename;
   TString str[8];
   Int_t ch;  
   Int_t nt;
   Double_t w;
   if (filen == "") {
      Error("LoadCostGradients()","Invalid file name");
      return kFALSE;
   }
   char *buff = new char[100];
   std::ifstream input(filen.Data());
   
   
   if (!input.is_open()) {
      delete[] buff;
      return kFALSE;
   }
   if (input.peek() == std::ifstream::traits_type::eof()) {
      return kFALSE; //empty
   }
   
   input.getline(buff, 200);
   input.getline(buff, 200);
   input.getline(buff, 200);

   for(int ic = 0; ic < ChipBoundary[nLAYER]; ic++){

      input >> str[0] >> str[1] >> str[2];
      if(str[0]=="") break;
      //input >> str;
      //input >> str;
      std::cout<<" ["<<ic<<"] "<<str[0]<<" "<<str[1]<<" "<<str[2]<<std::endl;
      TString ChipID = str[2].ReplaceAll("Chip","");
      ch = ChipID.TString::Atoi();
      std::cout<<"chipID : "<<ch<<std::endl;
      input >> nt;
      NTracks[ch] = nt;
      std::cout<<"ntracks : "<<nt<<std::endl;
      
      input >> str[4];
      input >> str[5];
      std::cout<<" ["<<ic<<"] "<<str[4]<<" "<<str[5]<<std::endl;
      gradCost[ch][0] = 0;
      gradCost[ch][1] = 0;      
      std::cout<<" dNP ";
      for (int iw=2; iw<11; iw++) { 
         input >> w;
         gradCost[ch][iw] = w;  
         std::cout<<gradCost[ch][iw]<<" ";
      }
      std::cout<<std::endl;
      input >> str[6];
      std::cout<<" ["<<ic<<"] "<<str[6]<<std::endl; 
      std::cout<<" dAP ";
      for (int iw=11; iw<17; iw++) { 
         input >> w;
         gradCost[ch][iw] = w;   
         std::cout<<gradCost[ch][iw]<<" ";    
      }
      std::cout<<std::endl; 
      input >> str[7];  
      std::cout<<" ["<<ic<<"] "<<str[7]<<std::endl;  
      
   }
   
   delete[] buff;
   return kTRUE;
}

void dumpWeightGradients(int nEpoch){

   TFile *file = new TFile(Form("CostGradients.root"),"recreate");   

   for(int ic=0; ic<ChipBoundary[nLAYER]; ic++){
      if(NTracks[ic]<100) continue;
      double ep[nEpoch];
      double wg[nW][nEpoch];
      double sum =0;
      for(int ie=0; ie<nEpoch; ie++){
         ep[ie] = ie;
         for(int ip=0; ip<nW; ip++){
            wg[ip][ie] = gradNetworkCost[ie][ic][ip];
            sum += wg[ip][ie];
         }
      }  
      if(sum==0) continue;
       
      //NP
      TGraph* gr_b1 = new TGraph(nEpoch, ep, wg[2]);    
      TGraph* gr_b2 = new TGraph(nEpoch, ep, wg[3]);    
      TGraph* gr_b3 = new TGraph(nEpoch, ep, wg[4]);    
      
      TGraph* gr_w11 = new TGraph(nEpoch, ep, wg[5]);    
      TGraph* gr_w21 = new TGraph(nEpoch, ep, wg[6]);    
      TGraph* gr_w12 = new TGraph(nEpoch, ep, wg[7]);    
      TGraph* gr_w22 = new TGraph(nEpoch, ep, wg[8]);    
      TGraph* gr_w13 = new TGraph(nEpoch, ep, wg[9]);    
      TGraph* gr_w23 = new TGraph(nEpoch, ep, wg[10]);   
      
      gr_b1->SetMarkerColor(2);
      gr_b2->SetMarkerColor(3);
      gr_b3->SetMarkerColor(4);    

      gr_w11->SetMarkerColor(2);
      gr_w21->SetMarkerColor(2);
      gr_w12->SetMarkerColor(3);    
      gr_w22->SetMarkerColor(3);
      gr_w13->SetMarkerColor(4);
      gr_w23->SetMarkerColor(4);          
                    
      gr_b1->SetMarkerStyle(20);
      gr_b2->SetMarkerStyle(20);
      gr_b3->SetMarkerStyle(20);    

      gr_w11->SetMarkerStyle(22);
      gr_w21->SetMarkerStyle(23);
      gr_w12->SetMarkerStyle(22);    
      gr_w22->SetMarkerStyle(23);
      gr_w13->SetMarkerStyle(22);
      gr_w23->SetMarkerStyle(23);   
        
      TMultiGraph *mg_NP = new TMultiGraph();
      mg_NP->Add(gr_b1,"p");
      mg_NP->Add(gr_b2,"p");    
      mg_NP->Add(gr_b3,"p");
      
      mg_NP->Add(gr_w11,"p");
      mg_NP->Add(gr_w21,"p");            
      mg_NP->Add(gr_w12,"p");            
      mg_NP->Add(gr_w22,"p");            
      mg_NP->Add(gr_w13,"p");            
      mg_NP->Add(gr_w23,"p");    
      
      mg_NP->SetTitle(Form("[Network Parameters] Chip %d, NTracks %d",ic,NTracks[ic]));
      mg_NP->GetXaxis()->SetTitle("Epoch");
      mg_NP->GetYaxis()->SetTitle("dC/d(NP)");
      mg_NP->GetYaxis()->SetTitleOffset(1.2);
 
      // Change the axis limits
      mg_NP->SetMinimum(-MONITOR_RANGE);
      mg_NP->SetMaximum(+MONITOR_RANGE);      
      
      file->cd();
   
      mg_NP->Draw("apl");
      auto legend = new TLegend(0.91,0.4,0.99,0.9);
      legend->AddEntry(gr_b1,"b1","p");
      legend->AddEntry(gr_b2,"b2","p");
      legend->AddEntry(gr_b3,"b3","p");
      
      legend->AddEntry(gr_w11,"w11","p");
      legend->AddEntry(gr_w21,"w21","p");
      legend->AddEntry(gr_w12,"w12","p");
      legend->AddEntry(gr_w22,"w22","p");
      legend->AddEntry(gr_w13,"w13","p");
      legend->AddEntry(gr_w23,"w23","p");                        
      legend->Draw("same");  
      mg_NP->Write(Form("NP_Chip%d",ic));           
      
      //AP 
      TGraph* gr_R1 = new TGraph(nEpoch, ep, wg[11]);    
      TGraph* gr_R2 = new TGraph(nEpoch, ep, wg[12]);    
      TGraph* gr_R3 = new TGraph(nEpoch, ep, wg[13]);    
      TGraph* gr_T1 = new TGraph(nEpoch, ep, wg[14]);    
      TGraph* gr_T2 = new TGraph(nEpoch, ep, wg[15]);    
      TGraph* gr_T3 = new TGraph(nEpoch, ep, wg[16]);   
      
      gr_R1->SetMarkerColor(2);
      gr_R2->SetMarkerColor(3);
      gr_R3->SetMarkerColor(4);    
      gr_T1->SetMarkerColor(2);
      gr_T2->SetMarkerColor(3);
      gr_T3->SetMarkerColor(4);          
                   
      gr_R1->SetMarkerStyle(23);
      gr_R2->SetMarkerStyle(23);
      gr_R3->SetMarkerStyle(23);    
      gr_T1->SetMarkerStyle(20);
      gr_T2->SetMarkerStyle(20);
      gr_T3->SetMarkerStyle(20);   
        
      TMultiGraph *mg_AP = new TMultiGraph();      
      mg_AP->Add(gr_R1,"p");
      mg_AP->Add(gr_R2,"p");            
      mg_AP->Add(gr_R3,"p");            
      mg_AP->Add(gr_T1,"p");            
      mg_AP->Add(gr_T2,"p");            
      mg_AP->Add(gr_T3,"p");    
      
      mg_AP->SetTitle(Form("[Align Parameters] Chip %d, NTracks %d",ic,NTracks[ic]));
      mg_AP->GetXaxis()->SetTitle("Epoch");
      mg_AP->GetYaxis()->SetTitle("dC/d(AP)");
      mg_AP->GetYaxis()->SetTitleOffset(1.2);
 
      // Change the axis limits
      mg_AP->SetMinimum(-MONITOR_RANGE);
      mg_AP->SetMaximum(+MONITOR_RANGE);      
      
      file->cd();
   
      mg_AP->Draw("apl");
      auto legend_AP = new TLegend(0.91,0.4,0.99,0.9);
      legend_AP->AddEntry(gr_R1,"R1","p");
      legend_AP->AddEntry(gr_R2,"R2","p");
      legend_AP->AddEntry(gr_R3,"R3","p");
      
      legend_AP->AddEntry(gr_T1,"T1","p");
      legend_AP->AddEntry(gr_T2,"T2","p");
      legend_AP->AddEntry(gr_T3,"T3","p");                       
      legend_AP->Draw("same");  
      mg_AP->Write(Form("AP_Chip%d",ic));           
        
      
                       
   }   
   
   file->Write();
   delete file;
}

//Step 5 6 7 8 9 10
void checkCostGradients(int iepoch=-1, int fepoch=9){

   int nEpoch = fepoch - iepoch;

   NTracks            = new int [ChipBoundary[nLAYER]];
   for(int ic=0; ic<ChipBoundary[nLAYER]; ic++){
      NTracks[ic] = 0;
   }

   gradNetworkCost = new double** [nEpoch];
   for(int ie=0; ie<nEpoch; ie++){
      gradNetworkCost[ie] = new double* [ChipBoundary[nLAYER]];      
      for(int ic=0; ic<ChipBoundary[nLAYER]; ic++){
         gradNetworkCost[ie][ic] = new double [nW];         
         for(int iw=0; iw<nW; iw++){
            gradNetworkCost[ie][ic][iw] = 0.0;            
         } 
      }
   }       
   
   for(int epoch = iepoch; epoch < fepoch; epoch++){
      TString wloc = Form("Cost_Gradient/CostGradient_Epoch_At_%d.txt",epoch+1);
      LoadCostGradients(wloc,gradNetworkCost[epoch+1]);
   }
   
   dumpWeightGradients(nEpoch);

}
