

void run_macros(int iepoch=-1, int fepoch=45){
   gROOT->ProcessLine(Form(".x checkCostGradients.C'(%d,%d)'",iepoch,fepoch));   
   
   //gROOT->ProcessLine(".L YDetectorGeometry.cxx");
   gROOT->ProcessLine(Form(".x checkWeightGradients_extended.C'(%d,%d)'",iepoch,fepoch));

}
